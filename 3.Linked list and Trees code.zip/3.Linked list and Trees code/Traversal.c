#include <stdio.h>
#include <stdlib.h>
struct node {
	int data;
	struct node* left;
	struct node* right;
};
struct node* newNode(int data)
{
	struct node* node = (struct node*)malloc(sizeof(struct node));
	node->data = data;
	node->left = NULL;
	node->right = NULL;

	return (node);
}

void Postorder(struct node* node)
{
	if (node == NULL)
		return;
	printPostorder(node->left);
	printPostorder(node->right);
	printf("%d ", node->data);
}

void Inorder(struct node* node)
{
	if (node == NULL)
		return;
	printInorder(node->left);
	printf("%d ", node->data);
	printInorder(node->right);
}

void Preorder(struct node* node)
{
	if (node == NULL)
		return;
	printf("%d ", node->data);
	printPreorder(node->left);
	printPreorder(node->right);
}
int main()
{
	struct node* root = newNode(16);
	root->left = newNode(12);
	root->right = newNode(31);
	root->left->left = newNode(14);
	root->left->right = newNode(35);
	root->left->left->left = newNode(16);
	root->left->left->right = newNode(23);
    root->left->right->right = newNode(47);
	printf("\nPreorder traversal \n");
	Preorder(root);
	printf("\nInorder traversal \n");
	Inorder(root);
	printf("\nPostorder traversal \n");
	Postorder(root);
	getchar();
	return 0;
}
