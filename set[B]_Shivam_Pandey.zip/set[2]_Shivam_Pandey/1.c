//Shivam Pandey(Nirma University)
#include<stdio.h>
#include<string.h>
void question1(char str[])
{
	int l=strlen(str);
	int i,j=0;
	for(i=1;i<=l;i++)
	{
		while(str[i]==str[j] && (j>=0))
		{
			i++;
			j--;
		}
		str[++j]=str[i];
	}
	if(strlen(str)==0)
		printf("Empty String");
	printf("%s",str);
}
int main()
{
	int n;
	scanf("%d",&n);
	char str[n];
	scanf("%s",str);
	question1(str);
	return 0;
}
