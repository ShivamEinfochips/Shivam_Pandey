//Shivam Pandey(Nirma University)
#include<stdio.h>    
#include<stdlib.h>  
int main(){  
int a[10],n,i;    
printf("Enter the number to convert: ");    
scanf("%d",&n);
int c=0;
for(i=0;n>0;i++)    
{    
a[i]=n%2;    
n=n/2;  
c++;
}    
for(i=i-1;i>=0;i--)    
{   
    if(i==c-1)
    {
        printf("Before: ");
    }
printf("%d",a[i]);    
}
printf("\n");
for(i=0;i<c;i++)
{
    if(i==0)
    {
        printf("After: ");
    }
    printf("%d",a[i]);    
}
return 0;  
} 